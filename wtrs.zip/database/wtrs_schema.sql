-- phpMyAdmin SQL Dump
-- WMSU Thesis Repository System (WTRS) Database Schema
-- Version 1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+08:00";

-- --------------------------------------------------------
-- Create the Database (Run this block first to reset/create database)
DROP DATABASE IF EXISTS `wtrs_db`;
CREATE DATABASE `wtrs_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `wtrs_db`;

-- --------------------------------------------------------
-- Table structure for table `users`
-- Handles authentication for both Students and Faculty Advisers (Admins)

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','adviser','admin') NOT NULL DEFAULT 'student',

  `college` varchar(150) DEFAULT NULL,
  `status` enum('pending','active','inactive') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert a default Administrator (Adviser Account) for system management
INSERT INTO `users` (`first_name`, `last_name`, `email`, `password`, `role`, `college`, `status`) VALUES
('System', 'Administrator', 'admin@wmsu.edu.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'College of Computing Studies', 'active');

-- Note: The default password above is 'password'. Change this upon login.

-- --------------------------------------------------------
-- Table structure for table `theses`
-- Core metadata for each research paper

CREATE TABLE `theses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thesis_code` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `abstract` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `adviser_id` int(11) DEFAULT NULL,
  `status` enum('draft','pending_review','revision_requested','approved','rejected','archived') NOT NULL DEFAULT 'draft',
  `views` int(11) NOT NULL DEFAULT '0',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `thesis_code` (`thesis_code`),
  FOREIGN KEY (`author_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`adviser_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- --------------------------------------------------------
-- Table structure for table `thesis_versions`
-- Tracking iterative file uploads strictly enforcing PDF constraints

CREATE TABLE `thesis_versions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thesis_id` int(11) NOT NULL,
  `version_number` varchar(20) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_size` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `feedback` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`thesis_id`) REFERENCES `theses`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- --------------------------------------------------------
-- Table structure for table `activity_logs`
-- Audit trail tracking for the Admin/Adviser Dashboard

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- --------------------------------------------------------
-- Table structure for table `system_settings`
-- Dynamic Application Parameters

CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('repository_name', 'WMSU Repository'),
('institution', 'Western Mindanao State University'),
('contact_email', 'repository.admin@wmsu.edu.ph'),
('max_file_size_mb', '20'),
('allow_guest_search', '1'),
('require_wmsu_email', '1');

COMMIT;
