<?php
// Central session and auth helper
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    // Session Security Hardening
    // Adjust cookie lifetime as needed (e.g., 86400 for 1 day)
    $cookieLifetime = 86400; 
    
    // Check if HTTPS is used; if so, enforce secure cookies.
    // XAMPP locally is generally HTTP, so we make it conditional for deployment.
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
    
    session_set_cookie_params([
        'lifetime' => $cookieLifetime,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => $isSecure,     // Only transmit over HTTPS if available
        'httponly' => true,        // Prevent JavaScript access to session cookie (mitigates XSS)
        'samesite' => 'Lax'        // Mitigate CSRF while allowing standard navigation
    ]);

    session_start();
}

require_once __DIR__ . '/db.php';

function is_logged_in() {
    return !empty($_SESSION['user_id']);
}

function current_user() {
    return isset($_SESSION['user']) ? $_SESSION['user'] : null;
}

function require_login($allowedRoles = []) {
    if (!is_logged_in()) {
        header('Location: ' . BASE_URL . 'auth/login.php');
        exit;
    }


    if (!empty($allowedRoles) && !in_array($_SESSION['user']['role'], $allowedRoles, true)) {
        header('HTTP/1.1 403 Forbidden');
        echo '<h1>403 Forbidden</h1><p>You do not have access to this page.</p>';
        exit;
    }
}
